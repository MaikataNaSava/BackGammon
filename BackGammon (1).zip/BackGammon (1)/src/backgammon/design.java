/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backgammon;

/**
 *
 * @author МомчилИванов
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Random;
import java.util.Stack;
//ww  w  .  j av a2s  . com
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class design {

    private int dice1, dice2;
    private int turn_index = 1;

    public int getTurn_index() {
        return turn_index;
    }

    public void setTurn_index(int turn_index) {
        this.turn_index = turn_index;
    }

    public int getDice1() {
        return dice1;
    }

    public void setDice1(int dice1) {
        this.dice1 = dice1;
    }

    public int getDice2() {
        return dice2;
    }

    public void setDice2(int dice2) {
        this.dice2 = dice2;
    }

    public static void main(String[] args) {
        ImagePanel panel = new ImagePanel(
                new ImageIcon("src/Image/table.png").getImage());
        JFrame frame = new JFrame();
        frame.getContentPane().add(panel);
        JPanel pnl_field0 = new JPanel();
        design obj = new design();
        JLabel turn = new JLabel();
        turn.setBounds(790, 284, 100, 150);
        turn.setText("Black's turn");
        turn.setForeground(Color.black);
        turn.setFont(new Font("Times New Roman", Font.ITALIC, 20));
        panel.add(turn);
        JPanel[] panel_arr = new JPanel[24];
        JButton roll = new JButton("Roll");
        roll.setIcon(new ImageIcon("src/Image/dice.gif"));
        roll.setBackground(new Color(0, 0, 128, 100));
        ImageIcon img1 = new ImageIcon("src/Image/rsz_120px-Dice-1.png");
        ImageIcon img2 = new ImageIcon("src/Image/rsz_120px-Dice-2.png");
        ImageIcon img3 = new ImageIcon("src/Image/rsz_120px-Dice-3.png");
        ImageIcon img4 = new ImageIcon("src/Image/rsz_120px-Dice-4.png");
        ImageIcon img5 = new ImageIcon("src/Image/rsz_120px-Dice-5.png");
        ImageIcon img6 = new ImageIcon("src/Image/rsz_120px-Dice-5.png");
        JButton EndTurn = new JButton("End turn");
        EndTurn.setVisible(false);
        Board obj2 = new Board();
        obj2.tablaBoard();
        ActionListener l1 = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int turn1 = obj.getTurn_index();
                EndTurn.setVisible(false);
                roll.setVisible(true);
                if (turn1 % 2 == 0) {
                    turn.setText("Black's turn");
                    turn.setForeground(Color.black);
                } else {
                    turn.setText("White's turn");
                    turn.setForeground(Color.white);
                }
                turn1++;
                obj.setTurn_index(turn1);
            }
        };
        JLabel label1 = new JLabel();
        JLabel label2 = new JLabel();
        ActionListener l = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EndTurn.setVisible(true);
                design obj = new design();
                label1.setBounds(700, 330, 90, 90);
                label2.setBounds(250, 330, 90, 90);
                Random rand = new Random();
                int dice12, dice13;
                dice12 = rand.nextInt(6) + 1;
                dice13 = rand.nextInt(6) + 1;
                switch (dice12) {
                    case 1:
                        label1.setIcon(img1);
                        break;
                    case 2:
                        label1.setIcon(img2);
                        break;
                    case 3:
                        label1.setIcon(img3);
                        break;
                    case 4:
                        label1.setIcon(img4);
                        break;
                    case 5:
                        label1.setIcon(img5);
                        break;
                    case 6:
                        label1.setIcon(img6);
                        break;
                }
                switch (dice13) {
                    case 1:
                        label2.setIcon(img1);
                        break;
                    case 2:
                        label2.setIcon(img2);
                        break;
                    case 3:
                        label2.setIcon(img3);
                        break;
                    case 4:
                        label2.setIcon(img4);
                        break;
                    case 5:
                        label2.setIcon(img5);
                        break;
                    case 6:
                        label2.setIcon(img6);
                        break;
                }
                obj.setDice1(dice12);
                obj.setDice2(dice13);
                panel.add(label1);
                panel.add(label2);
                roll.setVisible(false);
                panel.repaint();
            }
        };
        EndTurn.addActionListener(l1);
        roll.addActionListener(l);
        roll.setBounds(485, 350, 60, 60);
        int k = 0;
        for (int i = 0; i < 24; i++) {
            if (i < 6) {
                panel_arr[i] = new JPanel();
                panel_arr[i].setBounds(850 - i * 60, 30, 55, 300);
                panel_arr[i].setBackground(new Color(255, 255, 255, 0));
                panel.add(panel_arr[i]);
                panel_arr[i].setVisible(true);
            }
            if (i < 12 && i > 5) {
                panel_arr[i] = new JPanel();
                panel_arr[i].setBounds(840 - (i + 1) * 59, 30, 55, 300);
                panel_arr[i].setBackground(new Color(255, 255, 255, 0));
                panel.add(panel_arr[i]);
                panel_arr[i].setVisible(true);
            }
            if (i > 11 && i < 18) {
                panel_arr[i] = new JPanel();
                panel_arr[i].setBounds(130 + k * 60, 430, 55, 300);
                panel_arr[i].setBackground(new Color(255, 255, 255, 0));
                panel.add(panel_arr[i]);
                panel_arr[i].setVisible(true);
                k++;
            }
            if (i > 17) {
                panel_arr[i] = new JPanel();
                panel_arr[i].setBounds(190 + k * 60, 430, 55, 300);
                panel_arr[i].setBackground(new Color(255, 255, 255, 0));
                panel.add(panel_arr[i]);
                panel_arr[i].setVisible(true);
                k++;
            }
        }
        obj2.tablaBoard();
        for (int i = 0; i < 24; i++) {
            if (!obj2.getBoard().get(i).isEmpty()) {
                if ("Black".equals(obj2.getBoard().get(i).get(0))) {
                    //panel_arr[i].setLayout(new GridLayout(5,1));
                    for (int j = 0; j < obj2.getBoard().get(i).size() / 2; j++) {
                        JLabel label = new JLabel(
                                new ImageIcon("src/Image/rsz_1images.png"));
                        panel_arr[i].setLayout(new GridLayout(obj2.getBoard().get(i).size() / 2, 1, 0, 0));
                        panel_arr[i].add(label);
                        panel_arr[i].revalidate();
                        panel.repaint();
                    }
                } else {
                    //panel_arr[i].setLayout(new GridLayout(5,1));
                    for (int j = 0; j < obj2.getBoard().get(i).size() / 2; j++) {
                        JLabel label = new JLabel(
                                new ImageIcon("src/Image/white.png"));
                        panel_arr[i].setLayout(new GridLayout(obj2.getBoard().get(i).size() / 2, 1, 0, 0));
                        panel_arr[i].add(label);
                        panel_arr[i].revalidate();
                        panel.repaint();
                    }
                }
            }
        }
        panel.add(roll);
        EndTurn.setBounds(900, 350, 90, 50);
        EndTurn.setBackground(new Color(245, 245, 220));
        EndTurn.setForeground(Color.black);
        panel.add(EndTurn);
        frame.pack();
        frame.setVisible(true);
    }
}

class ImagePanel extends JPanel {

    private Image img;

    public ImagePanel(String img) {
        this(new ImageIcon(img).getImage());
    }

    public ImagePanel(Image img) {
        this.img = img;
        Dimension size = new Dimension(1024, 768);//(img.getWidth(null), img.getHeight(null));
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);
        setSize(size);
        setLayout(null);
    }

    public void paintComponent(Graphics g) {
        g.drawImage(img, 0, 0, null);
    }

}
